import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _isMaleChecked = false;
  bool _isFemaleChecked = false;
  bool _isSubmitted = false;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Jinsingizni tanlang'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Jinsingizni tanlang:',
                style: TextStyle(fontSize: 20),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Checkbox(
                    value: _isMaleChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        _isMaleChecked = value!;
                        _isFemaleChecked =
                            false; // faqat bitta tanlash imkoniyati
                      });
                    },
                  ),
                  Text('Erkak'),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Checkbox(
                    value: _isFemaleChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        _isFemaleChecked = value!;
                        _isMaleChecked =
                            false; // faqat bitta tanlash imkoniyati
                      });
                    },
                  ),
                  Text('Ayol'),
                ],
              ),
              ElevatedButton(
                onPressed: () {
                  if (_isMaleChecked || _isFemaleChecked) {
                    setState(() {
                      _isSubmitted = true;
                    });
                  }
                },
                child: Text('Javob berish'),
              ),
              if (_isSubmitted)
                Padding(
                  padding: const EdgeInsets.only(top: 20.0),
                  child: Text(
                    'Rahmat!',
                    style: TextStyle(fontSize: 24, color: Colors.green),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
